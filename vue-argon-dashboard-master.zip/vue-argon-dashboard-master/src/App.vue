<template>
  <div id="app">
    <notifications></notifications>
    <router-view/>
  </div>
</template>
